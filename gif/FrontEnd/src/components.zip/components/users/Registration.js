import React, { useState } from 'react';

const Registration = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    profileImage: null,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({
      ...formData,
      profileImage: file,
    });
  };

  const handleRegistration = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('username', formData.username);
    formData.append('password', formData.password);
    formData.append('profileImage', formData.profileImage);

    try {
      const response = await fetch('API_ENDPOINT/users/register', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        console.log('Registration successful!');
      } else {
        console.error('Registration failed');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <h2>Registration</h2>
      <form onSubmit={handleRegistration}>
        <input
          type="text"
          name="username"
          value={formData.username}
          onChange={handleInputChange}
          placeholder="Username"
        />
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          placeholder="Password"
        />
        <input
          type="file"
          name="profileImage"
          onChange={handleFileChange}
        />
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default Registration;
