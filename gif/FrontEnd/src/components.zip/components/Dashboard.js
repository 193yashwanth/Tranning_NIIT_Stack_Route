import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const history = useNavigate();

  const logout = () => {
    history('/');
  };

  return (
    <div>
      <nav>
        <Link to="/profile">Profile</Link>
        <Link to="/favorites">favorites</Link>
        <Link to="/recommendations">Recommendations</Link>
        <button onClick={logout}>Logout</button>
      </nav>
    </div>
  );
};

export default Dashboard;
