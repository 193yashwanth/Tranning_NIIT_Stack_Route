import axios from "axios";
import React, { useEffect, useState } from "react";

const Featch_Gif = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const featchData = async () => {
      const results = await axios("http://127.0.0.1:5000/gifs");
      setData(results.data);
    };
    featchData();
  }, []);

  function handleCount(gifId) {
    // Find the GIF in your local data
    const updatedData = data.map((gif) => {
      if (gif._id === gifId) {
        // Increment the count
        return { ...gif, count: (gif.count || 0) + 1 };
      }
      return gif;
    });

    // Update the local data with the incremented count
    setData(updatedData);
  }

  const renderGifs = () => {
    return data.map((el) => {
      return (
        <div key={el.id} className="gif">
          {/* ... Your existing code ... */}
          <button
            type="button"
            className="btn btn-outline-secondary"
            onClick={() => handleCount(el._id)} // Pass the GIF's ID to the function
          >
            {/* ... Your existing code ... */}
          </button>
        </div>
      );
    });
  };

  return <div className="gifs">{renderGifs()}</div>;
};

export default Featch_Gif;
