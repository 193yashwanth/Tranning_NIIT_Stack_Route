# from flask import Flask, request, jsonify
# from pymongo import MongoClient
# from bson import ObjectId
# from flask_cors import CORS
# import os
# from werkzeug.utils import secure_filename
# from werkzeug.security import generate_password_hash, check_password_hash
#
#
# def handle_uploaded_image(profile_picture):
#     # Ensure the 'uploads' directory exists
#     if not os.path.exists('uploads'):
#         os.makedirs('uploads')
#
#     # Save the uploaded file
#     filename = secure_filename(profile_picture.filename)
#     profile_picture.save(os.path.join('uploads', filename))
#
#     # Return the URL to the saved file
#     return f'/uploads/{filename}'
#
#
# app = Flask(__name__)
# CORS(app)
#
# client = MongoClient('mongodb://localhost:27017')
# db = client.gipher
#
# users = db.userdata
# gifs = db.gifdata
# favourites = db.favouritesdata
#
#
# # Method to add a new user
# @app.route('/users/register', methods=['POST'])
# def add_user():
#     username = request.form.get('username')
#     password = request.form.get('password')
#     profile_picture = request.files['profile_picture']
#
#     if not username or not password or not profile_picture:
#         return jsonify({'message': 'Invalid request data!'}), 400
#
#     if users.find_one({'username': username}):
#         return jsonify({'message': 'User already exists!'}), 409
#
#     profile_picture_url = handle_uploaded_image(profile_picture)
#     hashed_password = generate_password_hash(password, method='sha256')
#
#     user_id = users.insert_one(
#         {'username': username, 'password': hashed_password, 'profile_picture': profile_picture_url}).inserted_id
#     return jsonify({'message': 'Registration successful', 'user_id': str(user_id)}), 201
#
#
# # Method to login a user
# @app.route('/users/login', methods=['POST'])
# def login():
#     username = request.form.get('username')
#     password = request.form.get('password')
#
#     if not username or not password:
#         return jsonify({'message': "Couldn't verify"}), 400
#
#     user = users.find_one({'username': username})
#
#     if not user or not check_password_hash(user['password'], password):
#         return jsonify({'message': 'Invalid Credentials!'}), 401
#
#     return jsonify({'message': 'Login successful'}), 200
#
#
# # Method to update a user's profile
# @app.route('/users/profile', methods=['PUT'])
# def update_profile():
#     data = request.get_json()
#     username = data.get('username')
#     profile_picture = data.get('profile_picture')
#
#     if not username or not profile_picture:
#         return jsonify({'message': 'Invalid request data!'}), 400
#
#     user = users.find_one({'username': username})
#
#     if not user:
#         return jsonify({'message': 'User not found!'}), 404
#
#     users.update_one({'username': username}, {'$set': {'profile_picture': profile_picture}})
#     return jsonify({'message': 'Profile updated successfully'}), 200
#
#
# # Method to delete a user's account
# @app.route('/users/profile', methods=['DELETE'])
# def account_delete():
#     username = request.args.get('username')
#
#     if not username:
#         return jsonify({'message': 'Invalid request data!'}), 400
#
#     result = users.delete_one({'username': username})
#
#     if result.deleted_count == 0:
#         return jsonify({'message': 'User not found!'}), 404
#
#     return jsonify({'message': 'Account deleted'}), 200
#
#
# # Method to get all the GIFs
# @app.route('/gifs', methods=['GET'])
# def get_gifs():
#     gifs_collection = gifs.find()
#     gifs_list = []
#
#     for gif in gifs_collection:
#         gifs_list.append({
#             'id': str(gif['_id']),
#             'title': gif['title'],
#             'url': gif['url'],
#             'category': gif['category'],
#             "count": gif['count']
#         })
#
#     return jsonify(gifs_list), 200
#
#
# # Method to add a GIF to favorites
# @app.route('/favourites/add', methods=['POST'])
# def gif_to_fav():
#     data = request.get_json()
#     gif_id = data.get('gif_id')
#     user_id = data.get('user_id')
#
#     if not gif_id or not user_id:
#         return jsonify({'message': 'Invalid request data!'}), 400
#
#     if not users.find_one({'username': str(user_id)}):
#         return jsonify({'message': 'User not found!'}), 404
#
#     if not gifs.find_one({'_id': int(gif_id)}):
#         return jsonify({'message': 'GIF not found!'}), 404
#
#     if favourites.find_one({'username': user_id, '_id': gif_id}):
#         return jsonify({'message': 'GIF already in favorites!'}), 409
#
#     favourites.insert_one({'username': user_id, '_id': gif_id})
#     return jsonify({'message': 'GIF added to favorites'}), 201
#
# @app.route('/gifs/<gif_id_or_category>', methods=['GET'])
# def gifs_by_id_or_category(gif_id_or_category):
#     if gif_id_or_category.isdigit():
#         gif = gifs.find_one({'_id': int(gif_id_or_category)})
#         if gif:
#             return jsonify({
#                 'id': str(gif['_id']),
#                 'title': gif['title'],
#                 'url': gif['url'],
#                 'category': gif['category'],
#                 "count": gif['count']
#             }), 200
#         else:
#             return jsonify({'message': 'GIF not found!'}), 404
#     else:
#         gifs_list = list(gifs.find({'category': gif_id_or_category}))
#         if gifs_list:
#             response_data = []
#             for gif in gifs_list:
#                 response_data.append({
#                     'id': str(gif['_id']),
#                     'title': gif['title'],
#                     'url': gif['url'],
#                     'category': gif['category'],
#                     "count": gif['count']
#                 })
#             return jsonify(response_data), 200
#         else:
#             return jsonify({'message': 'No GIFs found in this category'}), 404
#
#
# # Method to view a user's favorites
# @app.route('/favourites/<user_id>', methods=['GET'])
# def view_fav(user_id):
#     user = users.find_one({'username': str(user_id)})
#
#     if not user:
#         return jsonify({'message': 'User not found!'}), 404
#
#     favorites_data = favourites.find({'username': user_id})
#     favorites_data_list = []
#
#     for favorite in favorites_data:
#         gif = gifs.find_one({'_id': favorite['_id']})
#
#         if gif:
#             favorites_data_list.append({
#                 'id': str(gif['_id']),
#                 'title': gif['title'],
#                 'url': gif['url'],
#                 'category': gif['category']
#             })
#
#     return jsonify(favorites_data_list), 200
#
# # Method to remove a GIF from favorites
# @app.route('/favourites/remove', methods=['DELETE'])
# def remove_gif_from_fav():
#     data = request.get_json()
#     gif_id = data.get('gif_id')
#     user_id = data.get('user_id')
#
#     if not gif_id or not user_id:
#         return jsonify({'message': 'Invalid request data!'}), 400
#
#     if not users.find_one({'username': str(user_id)}):
#         return jsonify({'message': 'User not found!'}), 404
#
#     if not gifs.find_one({'_id': int(gif_id)}):
#         return jsonify({'message': 'GIF not found!'}), 404
#
#     result = favourites.delete_one({'username': user_id, '_id': gif_id})
#
#     if result.deleted_count == 0:
#         return jsonify({'message': 'GIF not found in favorites!'}), 404
#
#     return jsonify({'message': 'GIF removed from favorites'}), 200
#
# from flask import Flask, request, jsonify
#
# @app.route('/gifs/incrementCount/<int:gif_id>', methods=['POST'])
# def increment_count(gif_id):
#     try:
#         # Find the GIF by its _id and increment the count field
#         gif = gifs.find_one({'_id': gif_id})
#
#         if gif:
#             new_count = gif.get('count', 0) + 1
#
#             # Update the count in the document
#             gifs.update_one({'_id': gif_id}, {'$set': {'count': new_count}})
#
#             # Return the updated count as JSON
#             return jsonify({'count': new_count}), 200
#         else:
#             return jsonify({'error': 'GIF not found'}), 404
#
#     except Exception as e:
#         return jsonify({'error': 'Error incrementing count'}), 500
#
#
#
#
#
# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
from flask_cors import CORS
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash


def handle_uploaded_image(profile_picture):
    # Ensure the 'uploads' directory exists
    if not os.path.exists('uploads'):
        os.makedirs('uploads')

    # Save the uploaded file
    filename = secure_filename(profile_picture.filename)
    profile_picture.save(os.path.join('uploads', filename))

    # Return the URL to the saved file
    return f'/uploads/{filename}'


app = Flask(__name__)
CORS(app)

client = MongoClient('mongodb://localhost:27017')
db = client.gipher

users = db.userdata
gifs = db.gifdata
favourites = db.favouritesdata


# Method to add a new user
@app.route('/users/register', methods=['POST'])
def add_user():
    username = request.form.get('username')
    password = request.form.get('password')
    profile_picture = request.files['profile_picture']
    print(request.files)

    if not username or not password or not profile_picture:
        return jsonify({'message': 'Invalid request data!'}), 409

    if users.find_one({'username': username}):
        return jsonify({'message': 'User already exists!'}), 409

    profile_picture_url = handle_uploaded_image(profile_picture)
    hashed_password = generate_password_hash(password, method='sha256')

    users.insert_one({'username': username, 'password': hashed_password, 'profile_picture': profile_picture_url})
    return jsonify({'message': 'Registration successful', 'username': username}), 201


# Method to login into a user
@app.route('/users/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        return jsonify({'message': "Couldn't verify"}), 401

    user = users.find_one({'username': username})

    if not user or not check_password_hash(user['password'], password):
        return jsonify({'message': 'Invalid Credentials!'}), 401

    return jsonify({'message': 'Login successful!', 'username': username}), 200


# Method to get user profile by username
@app.route('/users/<username>', methods=['GET'])
def get_user_profile(username):
    user = users.find_one({'username': username}, {'_id': False, 'password': False})

    if user:
        return jsonify({'user': user}), 200
    else:
        return jsonify({'message': 'User not found'}), 404


# Method to update user profile by username
@app.route('/users/<username>', methods=['PUT'])
def update_user_profile(username):
    new_username = request.form.get('username')  # Assuming you can update the username
    new_profile_picture = request.files.get('profile_picture')  # Assuming you can update the profile picture

    # Check if the user exists
    user = users.find_one({'username': username})
    if not user:
        return jsonify({'message': 'User not found'}), 404

    # Update the username if provided
    if new_username:
        users.update_one({'username': username}, {'$set': {'username': new_username}})

    # Update the profile picture if provided
    if new_profile_picture:
        # Handle the uploaded image
        profile_picture_url = handle_uploaded_image(new_profile_picture)

        # Update the profile picture URL in the database
        users.update_one({'username': username}, {'$set': {'profile_picture': profile_picture_url}})

    return jsonify({'message': 'Profile updated successfully'}), 200


# Method to delete a user profile by username
@app.route('/users/<username>', methods=['DELETE'])
def delete_user_profile(username):
    # Check if the user exists
    user = users.find_one({'username': username})
    if not user:
        return jsonify({'message': 'User not found'}), 404

    # Delete the user's profile picture file (optional, if needed)
    if 'profile_picture' in user and user['profile_picture']:
        # Extract filename from the URL
        filename = user['profile_picture'].split('/')[-1]
        file_path = os.path.join('uploads', filename)
        if os.path.exists(file_path):
            os.remove(file_path)

    # Delete the user's profile
    users.delete_one({'username': username})

    return jsonify({'message': 'Profile deleted successfully'}), 200


# Method to get all the gifs
@app.route('/gifs', methods=['GET'])
def get_gifs():
    gifs_collection = gifs.find()
    gifs_list = []

    for gif in gifs_collection:
        gifs_list.append({
            'id': str(gif['_id']),
            'title': gif['title'],
            'url': gif['url'],
            'category': gif['category']
        })

    return jsonify(gifs_list), 200


# Method to search a gif by id
@app.route('/gifs/<gif_id_or_category>', methods=['GET'])
def gifs_by_id_or_category(gif_id_or_category):
    if gif_id_or_category.isdigit():
        gif = gifs.find_one({'_id': int(gif_id_or_category)})
        if gif:
            return jsonify({
                'id': str(gif['_id']),
                'title': gif['title'],
                'url': gif['url'],
                'category': gif['category']
            }), 200
        else:
            return jsonify({'message': 'GIF not found!'}), 404
    else:
        gifs_list = list(gifs.find({'category': gif_id_or_category}))
        if gifs_list:
            response_data = []
            for gif in gifs_list:
                response_data.append({
                    'id': str(gif['_id']),
                    'title': gif['title'],
                    'url': gif['url'],
                    'category': gif['category']
                })
            return jsonify(response_data), 200
        else:
            return jsonify({'message': 'No GIFs found in this category'}), 404


# Method for adding GIF to favourites
@app.route('/favourites/add', methods=['POST'])
def gif_to_fav():
    data = request.get_json()
    gif_id = data['gif_id']  # '_id' from gifdata collection should be passed to here
    user_id = data['user_id']  # '_id' from userdata collection should be passed to here

    if favourites.find_one({'user_id': user_id, 'gif_id': gif_id}):
        return jsonify({'message': 'GIF already in favourites!'}), 405

    favourites.insert_one({'user_id': user_id, 'gif_id': gif_id})
    return jsonify({'message': 'GIF added to favourites!'}), 201


# Method to view favourites
@app.route('/favourites/<user_id>', methods=['GET'])
def view_fav(user_id):
    favourites_data = favourites.find_one({'user_id': user_id})
    favourites_data_list = []

    for favourite in favourites_data:
        gif = gifs.find_one({'_id': favourite['gif_id']})

        if gif:
            favourites_data_list.append({
                'id': str(gif['_id']),
                'title': gif['title'],
                'url': gif['url']
            })
    return jsonify(favourites_data_list), 200


app.add_url_rule('/uploads/<filename>', 'uploaded_file', build_only=True)

if __name__ == '__main__':
    app.run(debug=True)

